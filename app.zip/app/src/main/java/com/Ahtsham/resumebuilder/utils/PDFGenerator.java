package com.Ahtsham.resumebuilder.utils;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfDocument.Page;
import android.graphics.pdf.PdfDocument.PageInfo;
import android.os.Environment;

import com.Ahtsham.resumebuilder.model.ResumeData;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PDFGenerator {

    // ─── Page Dimensions (A4 in points) ──────────────────────────────────────────

    private static final int   PAGE_WIDTH   = 595;
    private static final int   PAGE_HEIGHT  = 842;

    // ─── Layout Constants ─────────────────────────────────────────────────────────

    private static final float MARGIN          = 36f;
    private static final float HEADER_HEIGHT   = 80f;
    private static final float SECTION_SPACING = 18f;
    private static final float LINE_SPACING    = 16f;
    private static final float SMALL_SPACING   = 6f;
    private static final float DIVIDER_Y_OFFSET= 10f;

    // Fix C5: Bottom overflow guard — text must stay above this y value
    private static final float MAX_Y = PAGE_HEIGHT - 30f;

    // ─── Colors ─────────────────────────────────────────────────────────────────
    // These must match colors.xml colorPrimary and colorSuccess (Fix S5 comment)

    private static final int COLOR_TEMPLATE_1   = Color.parseColor("#2563EB");
    private static final int COLOR_TEMPLATE_2   = Color.parseColor("#16A34A");
    private static final int COLOR_WHITE        = Color.WHITE;
    private static final int COLOR_GRAY         = Color.parseColor("#6B7280");
    private static final int COLOR_DARK         = Color.parseColor("#111827");
    private static final int COLOR_SECTION_BLUE = Color.parseColor("#2563EB");
    private static final int COLOR_DIVIDER      = Color.parseColor("#D1D5DB");
    private static final int COLOR_FOOTER_GRAY  = Color.parseColor("#9CA3AF");

    // ─── Entry Point ──────────────────────────────────────────────────────────────

    /**
     * Generates a PDF resume from the given ResumeData and saves it to the Downloads folder.
     * Fix W7: Appends a timestamp to the filename to prevent silent overwrite.
     *
     * @param context Android context
     * @param resume  the ResumeData object to render
     * @return the saved File, or null on any failure
     */
    public static File generatePDF(Context context, ResumeData resume) {
        PdfDocument  document = new PdfDocument();
        PageInfo     pageInfo = new PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create();
        Page         page     = document.startPage(pageInfo);
        Canvas       canvas   = page.getCanvas();

        try {
            float y = drawHeader(canvas, resume);
            y = drawContactLine(canvas, resume, y);
            y = drawDivider(canvas, y);
            y = drawEducationSection(canvas, resume, y);
            y = drawExperienceSection(canvas, resume, y);
            y = drawSkillsSection(canvas, resume, y);
            drawFooter(canvas);

            document.finishPage(page);

            // ── Save to Downloads ──────────────────────────────────────────────────
            File downloadsDir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS);
            if (!downloadsDir.exists()) {
                downloadsDir.mkdirs();
            }

            // Fix W7: Timestamp prevents silent overwrite of previous exports
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                    .format(new Date());
            String safeName = resume.getFullName() != null
                    ? resume.getFullName().replace(" ", "_")
                    : "Resume";
            File outputFile = new File(downloadsDir,
                    "Resume_" + safeName + "_" + timestamp + ".pdf");

            FileOutputStream fos = new FileOutputStream(outputFile);
            document.writeTo(fos);
            fos.flush();
            fos.close();

            return outputFile;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            document.close();
        }
    }

    // ─── Section Renderers ────────────────────────────────────────────────────────

    /**
     * Draws the colored header rectangle with name and job title.
     *
     * @return y position after the header
     */
    private static float drawHeader(Canvas canvas, ResumeData resume) {
        int headerColor = (resume.getSelectedTemplate() == 1)
                ? COLOR_TEMPLATE_1
                : COLOR_TEMPLATE_2;

        // Background rectangle
        Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bgPaint.setColor(headerColor);
        bgPaint.setStyle(Style.FILL);
        canvas.drawRect(new RectF(0, 0, PAGE_WIDTH, HEADER_HEIGHT), bgPaint);

        // Full name — white, bold, 22sp
        Paint namePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        namePaint.setColor(COLOR_WHITE);
        namePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        namePaint.setTextSize(22f);
        namePaint.setTextAlign(Align.LEFT);
        canvas.drawText(safeString(resume.getFullName()), MARGIN, 34f, namePaint);

        // Job title — white, normal, 14sp
        Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        titlePaint.setColor(COLOR_WHITE);
        titlePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        titlePaint.setTextSize(14f);
        titlePaint.setTextAlign(Align.LEFT);
        canvas.drawText(safeString(resume.getJobTitle()), MARGIN, 58f, titlePaint);

        return HEADER_HEIGHT + SMALL_SPACING;
    }

    /**
     * Draws the contact info line (email | phone | address | linkedin) below the header.
     * Fix W6: LinkedIn is now included in the contact line.
     *
     * @return y position after the contact line
     */
    private static float drawContactLine(Canvas canvas, ResumeData resume, float startY) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(COLOR_GRAY);
        paint.setTextSize(10f);
        paint.setTextAlign(Align.LEFT);

        StringBuilder contact = new StringBuilder();
        appendIfNotEmpty(contact, resume.getEmail());
        appendWithSeparator(contact, resume.getPhone());
        appendWithSeparator(contact, resume.getAddress());
        // Fix W6: LinkedIn was collected but never exported — now included
        appendWithSeparator(contact, resume.getLinkedin());

        float y = startY + LINE_SPACING;
        // Use drawWrappedText so long contact lines don't clip off the page edge
        y = drawWrappedText(canvas, contact.toString(), y, paint);
        return y + SMALL_SPACING;
    }

    /**
     * Draws a full-width horizontal divider line.
     *
     * @return y position after the divider
     */
    private static float drawDivider(Canvas canvas, float startY) {
        float y = startY + DIVIDER_Y_OFFSET;
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(COLOR_DIVIDER);
        paint.setStrokeWidth(1f);
        canvas.drawLine(MARGIN, y, PAGE_WIDTH - MARGIN, y, paint);
        return y + SECTION_SPACING;
    }

    /**
     * Draws the EDUCATION section.
     *
     * @return y position after the section
     */
    private static float drawEducationSection(Canvas canvas, ResumeData resume, float startY) {
        float y = startY;
        y = drawSectionHeader(canvas, "EDUCATION", y);

        String school = safeString(resume.getSchool());
        String degree = safeString(resume.getDegree());
        String field  = safeString(resume.getFieldOfStudy());
        String dates  = formatDateRange(resume.getEduStartDate(), resume.getEduEndDate());
        String grade  = safeString(resume.getGrade());
        String desc   = safeString(resume.getEduDescription());

        Paint bodyPaint = makeBodyPaint();

        if (!school.isEmpty()) {
            y = drawBodyLine(canvas, school, y, bodyPaint, Typeface.BOLD);
        }
        if (!degree.isEmpty() || !field.isEmpty()) {
            String degreeField = degree
                    + ((!degree.isEmpty() && !field.isEmpty()) ? " — " : "")
                    + field;
            y = drawBodyLine(canvas, degreeField, y, bodyPaint, Typeface.NORMAL);
        }
        if (!dates.isEmpty()) {
            y = drawBodyLine(canvas, dates, y, bodyPaint, Typeface.ITALIC);
        }
        if (!grade.isEmpty()) {
            y = drawBodyLine(canvas, "Grade: " + grade, y, bodyPaint, Typeface.NORMAL);
        }
        if (!desc.isEmpty()) {
            y = drawWrappedText(canvas, desc, y, bodyPaint);
        }

        return y + SECTION_SPACING;
    }

    /**
     * Draws the EXPERIENCE section.
     *
     * @return y position after the section
     */
    private static float drawExperienceSection(Canvas canvas, ResumeData resume, float startY) {
        float y = startY;
        y = drawSectionHeader(canvas, "EXPERIENCE", y);

        String company  = safeString(resume.getCompanyName());
        String jobTitle = safeString(resume.getExpJobTitle());
        String location = safeString(resume.getExpLocation());
        String dates    = formatDateRange(resume.getExpStartDate(), resume.getExpEndDate());
        String duties   = safeString(resume.getResponsibilities());

        Paint bodyPaint = makeBodyPaint();

        if (!company.isEmpty()) {
            y = drawBodyLine(canvas, company, y, bodyPaint, Typeface.BOLD);
        }
        if (!jobTitle.isEmpty()) {
            String titleLoc = jobTitle
                    + ((!jobTitle.isEmpty() && !location.isEmpty()) ? " · " : "")
                    + location;
            y = drawBodyLine(canvas, titleLoc, y, bodyPaint, Typeface.NORMAL);
        }
        if (!dates.isEmpty()) {
            y = drawBodyLine(canvas, dates, y, bodyPaint, Typeface.ITALIC);
        }
        if (!duties.isEmpty()) {
            y = drawWrappedText(canvas, duties, y, bodyPaint);
        }

        return y + SECTION_SPACING;
    }

    /**
     * Draws the SKILLS section.
     *
     * @return y position after the section
     */
    private static float drawSkillsSection(Canvas canvas, ResumeData resume, float startY) {
        float y = startY;
        y = drawSectionHeader(canvas, "SKILLS", y);

        String skills = safeString(resume.getSkills());
        if (!skills.isEmpty()) {
            Paint bodyPaint = makeBodyPaint();
            y = drawWrappedText(canvas, skills, y, bodyPaint);
        }

        return y + SECTION_SPACING;
    }

    /**
     * Draws the footer text at the bottom of the page.
     */
    private static void drawFooter(Canvas canvas) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(COLOR_FOOTER_GRAY);
        paint.setTextSize(9f);
        paint.setTextAlign(Align.CENTER);
        canvas.drawText("Generated by Resume Builder",
                PAGE_WIDTH / 2f, PAGE_HEIGHT - 20f, paint);
    }

    // ─── Drawing Primitives ───────────────────────────────────────────────────────

    /**
     * Draws a bold underlined section header label.
     *
     * @return y position after the header label
     */
    private static float drawSectionHeader(Canvas canvas, String title, float y) {
        if (y > MAX_Y) return y; // overflow guard
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(COLOR_SECTION_BLUE);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(13f);
        paint.setUnderlineText(true);
        paint.setTextAlign(Align.LEFT);
        canvas.drawText(title, MARGIN, y, paint);
        return y + LINE_SPACING;
    }

    /**
     * Fix C5: Draws a single line of body text with an overflow guard.
     * If y has already exceeded MAX_Y the line is silently skipped rather
     * than drawn off the visible page area.
     *
     * @return y position after the drawn line
     */
    private static float drawBodyLine(Canvas canvas, String text, float y,
                                      Paint basePaint, int typefaceStyle) {
        if (y > MAX_Y) return y; // overflow guard — skip lines beyond page
        Paint paint = new Paint(basePaint);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, typefaceStyle));
        canvas.drawText(text, MARGIN, y, paint);
        return y + LINE_SPACING;
    }

    /**
     * Fix C5 + S3: Draws body text wrapped to fit within the page margins.
     * Overflow guard prevents text from being drawn below MAX_Y.
     * Long single-word fallback prevents URLs/emails from silently disappearing.
     *
     * @return y position after the wrapped text block
     */
    private static float drawWrappedText(Canvas canvas, String text, float y, Paint paint) {
        float    maxWidth = PAGE_WIDTH - (MARGIN * 2);
        String[] words    = text.split(" ");
        StringBuilder line = new StringBuilder();

        for (String word : words) {
            String candidate = line.length() == 0 ? word : line + " " + word;
            if (paint.measureText(candidate) <= maxWidth) {
                line = new StringBuilder(candidate);
            } else {
                if (line.length() > 0) {
                    // Draw the accumulated line before starting a new one
                    if (y <= MAX_Y) {
                        canvas.drawText(line.toString(), MARGIN, y, paint);
                        y += LINE_SPACING;
                    }
                    line = new StringBuilder(word);
                } else {
                    // Fix S3: Single word is wider than the page — draw it anyway
                    // (it will clip at the edge but at least it won't disappear)
                    if (y <= MAX_Y) {
                        canvas.drawText(word, MARGIN, y, paint);
                        y += LINE_SPACING;
                    }
                }
            }
        }

        // Draw any remaining text in the buffer
        if (line.length() > 0 && y <= MAX_Y) {
            canvas.drawText(line.toString(), MARGIN, y, paint);
            y += LINE_SPACING;
        }

        return y;
    }

    // ─── Paint Factory ────────────────────────────────────────────────────────────

    private static Paint makeBodyPaint() {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(COLOR_DARK);
        paint.setTextSize(11f);
        paint.setTextAlign(Align.LEFT);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        return paint;
    }

    // ─── Utility Helpers ──────────────────────────────────────────────────────────

    private static String safeString(String value) {
        return (value != null) ? value.trim() : "";
    }

    private static String formatDateRange(String start, String end) {
        String s = safeString(start);
        String e = safeString(end);
        if (s.isEmpty() && e.isEmpty()) return "";
        if (s.isEmpty()) return e;
        if (e.isEmpty()) return s + " — Present";
        return s + " — " + e;
    }

    private static void appendIfNotEmpty(StringBuilder sb, String value) {
        String s = safeString(value);
        if (!s.isEmpty()) sb.append(s);
    }

    private static void appendWithSeparator(StringBuilder sb, String value) {
        String s = safeString(value);
        if (!s.isEmpty()) {
            if (sb.length() > 0) sb.append("  |  ");
            sb.append(s);
        }
    }
}
