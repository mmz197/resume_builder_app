package com.Ahtsham.resumebuilder;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.Ahtsham.resumebuilder.adapter.ResumeAdapter;
import com.Ahtsham.resumebuilder.database.DatabaseHelper;
import com.Ahtsham.resumebuilder.model.ResumeData;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity
        implements ResumeAdapter.OnResumeActionListener {

    private DatabaseHelper   db;
    private ResumeAdapter    adapter;
    private List<ResumeData> resumeList;
    private RecyclerView     rvResumes;
    private TextView         tvEmptyState;
    private MaterialButton   btnCreateResume;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        db              = new DatabaseHelper(this);
        rvResumes       = findViewById(R.id.rvResumes);
        tvEmptyState    = findViewById(R.id.tvEmptyState);
        btnCreateResume = findViewById(R.id.btnCreateResume);

        // Fix W3: Initialize adapter with empty list — onResume() will populate it,
        // avoiding the double DB query that happened when onCreate called loadResumes()
        // and then onResume() called it again immediately after.
        adapter = new ResumeAdapter(new ArrayList<>(), this);
        rvResumes.setLayoutManager(new LinearLayoutManager(this));
        rvResumes.setAdapter(adapter);

        btnCreateResume.setOnClickListener(v ->
                startActivity(new Intent(this, Personal_Info_Activity.class)));

        // Fix W3: Removed duplicate loadResumes() call from here.
        // onResume() handles the initial load and all subsequent refreshes.
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadResumes();
    }

    // Fix W1: Close DatabaseHelper when activity is destroyed to prevent resource leak
    @Override
    protected void onDestroy() {
        if (db != null) db.close();
        super.onDestroy();
    }

    private void loadResumes() {
        resumeList = db.getAllResumes();
        // Fix W4: Always update the adapter — previously updateList() was skipped
        // in the empty branch, leaving stale data in the adapter.
        adapter.updateList(resumeList);
        if (resumeList.isEmpty()) {
            tvEmptyState.setVisibility(View.VISIBLE);
            rvResumes.setVisibility(View.GONE);
        } else {
            tvEmptyState.setVisibility(View.GONE);
            rvResumes.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onPreview(ResumeData resume) {
        Intent intent = new Intent(this, PreviewActivity.class);
        intent.putExtra("resumeData", resume);
        startActivity(intent);
    }

    @Override
    public void onDelete(ResumeData resume) {
        db.deleteResume(resume.getId());
        loadResumes();
        Toast.makeText(this, "Resume deleted", Toast.LENGTH_SHORT).show();
    }
}
