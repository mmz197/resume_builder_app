package com.Ahtsham.resumebuilder;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.Ahtsham.resumebuilder.model.ResumeData;

public class TemplateActivity extends AppCompatActivity {

    private MaterialCardView card1, card2;
    private TextView         check1, check2, btnBack;
    private MaterialButton   btnPreviewResume;
    private ResumeData       resumeData;
    private int              selectedTemplate = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_template);

        // W5: API 33+ typed getSerializableExtra
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            resumeData = getIntent().getSerializableExtra("resumeData", ResumeData.class);
        } else {
            //noinspection deprecation
            resumeData = (ResumeData) getIntent().getSerializableExtra("resumeData");
        }
        if (resumeData == null) resumeData = new ResumeData();

        card1            = findViewById(R.id.card1);
        card2            = findViewById(R.id.card2);
        check1           = findViewById(R.id.check1);
        check2           = findViewById(R.id.check2);
        btnBack          = findViewById(R.id.btnBack);
        btnPreviewResume = findViewById(R.id.btnPreviewResume);

        selectTemplate(1); // default selection

        card1.setOnClickListener(v -> selectTemplate(1));
        card2.setOnClickListener(v -> selectTemplate(2));
        btnBack.setOnClickListener(v -> finish());

        btnPreviewResume.setOnClickListener(v -> {
            resumeData.setSelectedTemplate(selectedTemplate);
            Intent intent = new Intent(this, PreviewActivity.class);
            intent.putExtra("resumeData", resumeData);
            startActivity(intent);
        });
    }

    private void selectTemplate(int templateNum) {
        selectedTemplate = templateNum;

        // Fix: Use ContextCompat.getColor() instead of Color.parseColor() hardcoded hex
        int primaryColor  = ContextCompat.getColor(this, R.color.colorPrimary);
        int successColor  = ContextCompat.getColor(this, R.color.colorSuccess);
        int dividerColor  = ContextCompat.getColor(this, R.color.colorDivider);

        if (templateNum == 1) {
            card1.setStrokeColor(primaryColor);
            card1.setStrokeWidth(dpToPx(3));
            check1.setVisibility(View.VISIBLE);

            card2.setStrokeColor(dividerColor);
            card2.setStrokeWidth(dpToPx(1));
            check2.setVisibility(View.GONE);
        } else {
            card2.setStrokeColor(successColor);
            card2.setStrokeWidth(dpToPx(3));
            check2.setVisibility(View.VISIBLE);

            card1.setStrokeColor(dividerColor);
            card1.setStrokeWidth(dpToPx(1));
            check1.setVisibility(View.GONE);
        }
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}
