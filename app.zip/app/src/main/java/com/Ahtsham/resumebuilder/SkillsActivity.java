package com.Ahtsham.resumebuilder;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.Ahtsham.resumebuilder.model.ResumeData;

import java.util.ArrayList;

public class SkillsActivity extends AppCompatActivity {

    private TextInputEditText etSkillInput;
    private MaterialButton    btnAddSkill, btnNextTemplate;
    private ChipGroup         cgSkills;
    private TextView          btnBack;
    private ResumeData        resumeData;
    private ArrayList<String> skillsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_skills);

        // Fix W5: Use typed getSerializableExtra on API 33+, suppress deprecation below
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            resumeData = getIntent().getSerializableExtra("resumeData", ResumeData.class);
        } else {
            //noinspection deprecation
            resumeData = (ResumeData) getIntent().getSerializableExtra("resumeData");
        }
        if (resumeData == null) resumeData = new ResumeData();

        // Find views
        etSkillInput    = findViewById(R.id.etSkillInput);
        btnAddSkill     = findViewById(R.id.btnAddSkill);
        btnNextTemplate = findViewById(R.id.btnNextTemplate);
        cgSkills        = findViewById(R.id.cgSkills);
        btnBack         = findViewById(R.id.btnBack);

        // Load existing skills if editing
        if (resumeData.getSkills() != null && !resumeData.getSkills().isEmpty()) {
            for (String skill : resumeData.getSkills().split(",")) {
                String trimmed = skill.trim();
                if (!trimmed.isEmpty()) addSkillChip(trimmed);
            }
        }

        btnBack.setOnClickListener(v -> finish());

        btnAddSkill.setOnClickListener(v -> {
            String skill = etSkillInput.getText().toString().trim();
            if (!skill.isEmpty()) {
                addSkillChip(skill);
                etSkillInput.setText("");
                hideKeyboard();
            } else {
                Toast.makeText(this, "Please type a skill first",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Suggestion chips
        setupSuggestionChip(R.id.chipSug1, "Communication");
        setupSuggestionChip(R.id.chipSug2, "Leadership");
        setupSuggestionChip(R.id.chipSug3, "MS Office");
        setupSuggestionChip(R.id.chipSug4, "Problem Solving");
        setupSuggestionChip(R.id.chipSug5, "Teamwork");
        setupSuggestionChip(R.id.chipSug6, "Time Management");

        btnNextTemplate.setOnClickListener(v -> {
            if (skillsList.isEmpty()) {
                Toast.makeText(this, "Please add at least one skill",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            resumeData.setSkills(String.join(", ", skillsList));
            Intent intent = new Intent(this, TemplateActivity.class);
            intent.putExtra("resumeData", resumeData);
            startActivity(intent);
        });
    }

    private void addSkillChip(String skillName) {
        if (skillsList.contains(skillName)) {
            Toast.makeText(this, skillName + " already added",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        skillsList.add(skillName);

        Chip chip = new Chip(this);
        chip.setText(skillName);
        chip.setCloseIconVisible(true);
        chip.setChipBackgroundColorResource(R.color.colorPrimaryLight);
        chip.setTextColor(getColor(R.color.colorPrimary));
        chip.setCloseIconTint(
                android.content.res.ColorStateList.valueOf(getColor(R.color.colorPrimary)));

        chip.setOnCloseIconClickListener(v -> {
            cgSkills.removeView(chip);
            skillsList.remove(skillName);
        });

        cgSkills.addView(chip);
    }

    private void setupSuggestionChip(int chipId, String skillName) {
        Chip chip = findViewById(chipId);
        chip.setOnClickListener(v -> addSkillChip(skillName));
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null && getCurrentFocus() != null) {
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }
}
