package com.Ahtsham.resumebuilder.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.Ahtsham.resumebuilder.model.ResumeData;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME    = "resume_builder.db";
    private static final int    DATABASE_VERSION = 1;
    private static final String TABLE_NAME       = "resumes";

    // Column names
    private static final String COL_ID               = "id";
    private static final String COL_FULL_NAME        = "full_name";
    private static final String COL_JOB_TITLE        = "job_title";
    private static final String COL_EMAIL            = "email";
    private static final String COL_PHONE            = "phone";
    private static final String COL_ADDRESS          = "address";
    private static final String COL_LINKEDIN         = "linkedin";
    private static final String COL_SCHOOL           = "school";
    private static final String COL_DEGREE           = "degree";
    private static final String COL_FIELD            = "field_of_study";
    private static final String COL_EDU_START        = "edu_start_date";
    private static final String COL_EDU_END          = "edu_end_date";
    private static final String COL_GRADE            = "grade";
    private static final String COL_EDU_DESC         = "edu_description";
    private static final String COL_COMPANY          = "company_name";
    private static final String COL_EXP_TITLE        = "exp_job_title";
    private static final String COL_EXP_LOCATION     = "exp_location";
    private static final String COL_EXP_START        = "exp_start_date";
    private static final String COL_EXP_END          = "exp_end_date";
    private static final String COL_RESPONSIBILITIES = "responsibilities";
    private static final String COL_SKILLS           = "skills";
    private static final String COL_TEMPLATE         = "selected_template";
    private static final String COL_DATE_CREATED     = "date_created";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " ("
                + COL_ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_FULL_NAME        + " TEXT, "
                + COL_JOB_TITLE        + " TEXT, "
                + COL_EMAIL            + " TEXT, "
                + COL_PHONE            + " TEXT, "
                + COL_ADDRESS          + " TEXT, "
                + COL_LINKEDIN         + " TEXT, "
                + COL_SCHOOL           + " TEXT, "
                + COL_DEGREE           + " TEXT, "
                + COL_FIELD            + " TEXT, "
                + COL_EDU_START        + " TEXT, "
                + COL_EDU_END          + " TEXT, "
                + COL_GRADE            + " TEXT, "
                + COL_EDU_DESC         + " TEXT, "
                + COL_COMPANY          + " TEXT, "
                + COL_EXP_TITLE        + " TEXT, "
                + COL_EXP_LOCATION     + " TEXT, "
                + COL_EXP_START        + " TEXT, "
                + COL_EXP_END          + " TEXT, "
                + COL_RESPONSIBILITIES + " TEXT, "
                + COL_SKILLS           + " TEXT, "
                + COL_TEMPLATE         + " INTEGER DEFAULT 1, "
                + COL_DATE_CREATED     + " TEXT)";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // ── CRUD Methods ───────────────────────────────────────────────────────────────
    //
    // Fix W2: Removed db.close() from every method.
    // SQLiteOpenHelper manages the connection internally — calling close() after each
    // operation risks IllegalStateException when two operations run close together
    // (e.g. insert in saveOrUpdateResume followed immediately by getAllResumes in
    // onResume). Activities are responsible for calling close() in their onDestroy().

    // INSERT
    public long insertResume(ResumeData r) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = buildContentValues(r);
        return db.insert(TABLE_NAME, null, cv);
    }

    // GET ALL
    public List<ResumeData> getAllResumes() {
        List<ResumeData> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_NAME + " ORDER BY " + COL_ID + " DESC",
                null);
        if (cursor.moveToFirst()) {
            do { list.add(cursorToResume(cursor)); }
            while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    // GET BY ID
    public ResumeData getResumeById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_NAME + " WHERE " + COL_ID + "=?",
                new String[]{String.valueOf(id)});
        ResumeData resume = null;
        if (cursor.moveToFirst()) resume = cursorToResume(cursor);
        cursor.close();
        return resume;
    }

    // UPDATE
    public int updateResume(ResumeData r) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = buildContentValues(r);
        return db.update(TABLE_NAME, cv, COL_ID + "=?",
                new String[]{String.valueOf(r.getId())});
    }

    // DELETE
    public void deleteResume(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COL_ID + "=?", new String[]{String.valueOf(id)});
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private ContentValues buildContentValues(ResumeData r) {
        ContentValues cv = new ContentValues();
        cv.put(COL_FULL_NAME,        r.getFullName());
        cv.put(COL_JOB_TITLE,        r.getJobTitle());
        cv.put(COL_EMAIL,            r.getEmail());
        cv.put(COL_PHONE,            r.getPhone());
        cv.put(COL_ADDRESS,          r.getAddress());
        cv.put(COL_LINKEDIN,         r.getLinkedin());
        cv.put(COL_SCHOOL,           r.getSchool());
        cv.put(COL_DEGREE,           r.getDegree());
        cv.put(COL_FIELD,            r.getFieldOfStudy());
        cv.put(COL_EDU_START,        r.getEduStartDate());
        cv.put(COL_EDU_END,          r.getEduEndDate());
        cv.put(COL_GRADE,            r.getGrade());
        cv.put(COL_EDU_DESC,         r.getEduDescription());
        cv.put(COL_COMPANY,          r.getCompanyName());
        cv.put(COL_EXP_TITLE,        r.getExpJobTitle());
        cv.put(COL_EXP_LOCATION,     r.getExpLocation());
        cv.put(COL_EXP_START,        r.getExpStartDate());
        cv.put(COL_EXP_END,          r.getExpEndDate());
        cv.put(COL_RESPONSIBILITIES, r.getResponsibilities());
        cv.put(COL_SKILLS,           r.getSkills());
        cv.put(COL_TEMPLATE,         r.getSelectedTemplate());
        cv.put(COL_DATE_CREATED,     r.getDateCreated());
        return cv;
    }

    private ResumeData cursorToResume(Cursor c) {
        ResumeData r = new ResumeData();
        r.setId(              c.getInt(   c.getColumnIndexOrThrow(COL_ID)));
        r.setFullName(        c.getString(c.getColumnIndexOrThrow(COL_FULL_NAME)));
        r.setJobTitle(        c.getString(c.getColumnIndexOrThrow(COL_JOB_TITLE)));
        r.setEmail(           c.getString(c.getColumnIndexOrThrow(COL_EMAIL)));
        r.setPhone(           c.getString(c.getColumnIndexOrThrow(COL_PHONE)));
        r.setAddress(         c.getString(c.getColumnIndexOrThrow(COL_ADDRESS)));
        r.setLinkedin(        c.getString(c.getColumnIndexOrThrow(COL_LINKEDIN)));
        r.setSchool(          c.getString(c.getColumnIndexOrThrow(COL_SCHOOL)));
        r.setDegree(          c.getString(c.getColumnIndexOrThrow(COL_DEGREE)));
        r.setFieldOfStudy(    c.getString(c.getColumnIndexOrThrow(COL_FIELD)));
        r.setEduStartDate(    c.getString(c.getColumnIndexOrThrow(COL_EDU_START)));
        r.setEduEndDate(      c.getString(c.getColumnIndexOrThrow(COL_EDU_END)));
        r.setGrade(           c.getString(c.getColumnIndexOrThrow(COL_GRADE)));
        r.setEduDescription(  c.getString(c.getColumnIndexOrThrow(COL_EDU_DESC)));
        r.setCompanyName(     c.getString(c.getColumnIndexOrThrow(COL_COMPANY)));
        r.setExpJobTitle(     c.getString(c.getColumnIndexOrThrow(COL_EXP_TITLE)));
        r.setExpLocation(     c.getString(c.getColumnIndexOrThrow(COL_EXP_LOCATION)));
        r.setExpStartDate(    c.getString(c.getColumnIndexOrThrow(COL_EXP_START)));
        r.setExpEndDate(      c.getString(c.getColumnIndexOrThrow(COL_EXP_END)));
        r.setResponsibilities(c.getString(c.getColumnIndexOrThrow(COL_RESPONSIBILITIES)));
        r.setSkills(          c.getString(c.getColumnIndexOrThrow(COL_SKILLS)));
        r.setSelectedTemplate(c.getInt(   c.getColumnIndexOrThrow(COL_TEMPLATE)));
        r.setDateCreated(     c.getString(c.getColumnIndexOrThrow(COL_DATE_CREATED)));
        return r;
    }
}
