package com.Ahtsham.resumebuilder.model;

import java.io.Serializable;

public class ResumeData implements Serializable {

    // Fix S1: Explicit serialVersionUID prevents InvalidClassException if fields
    // are ever added/removed from this class in the future.
    private static final long serialVersionUID = 1L;

    // Personal
    private int    id;
    private String fullName;
    private String jobTitle;
    private String email;
    private String phone;
    private String address;
    private String linkedin;

    // Education
    private String school;
    private String degree;
    private String fieldOfStudy;
    private String eduStartDate;
    private String eduEndDate;
    private String grade;
    private String eduDescription;

    // Experience
    private String companyName;
    private String expJobTitle;
    private String expLocation;
    private String expStartDate;
    private String expEndDate;
    private String responsibilities;

    // Skills
    private String skills;

    // Template
    private int selectedTemplate = 1;

    // Meta
    private String dateCreated;

    // Empty constructor
    public ResumeData() {}

    // Full constructor
    public ResumeData(int id, String fullName, String jobTitle,
                      String email, String phone, String address,
                      String linkedin, String school, String degree,
                      String fieldOfStudy, String eduStartDate,
                      String eduEndDate, String grade,
                      String eduDescription, String companyName,
                      String expJobTitle, String expLocation,
                      String expStartDate, String expEndDate,
                      String responsibilities, String skills,
                      int selectedTemplate, String dateCreated) {
        this.id               = id;
        this.fullName         = fullName;
        this.jobTitle         = jobTitle;
        this.email            = email;
        this.phone            = phone;
        this.address          = address;
        this.linkedin         = linkedin;
        this.school           = school;
        this.degree           = degree;
        this.fieldOfStudy     = fieldOfStudy;
        this.eduStartDate     = eduStartDate;
        this.eduEndDate       = eduEndDate;
        this.grade            = grade;
        this.eduDescription   = eduDescription;
        this.companyName      = companyName;
        this.expJobTitle      = expJobTitle;
        this.expLocation      = expLocation;
        this.expStartDate     = expStartDate;
        this.expEndDate       = expEndDate;
        this.responsibilities = responsibilities;
        this.skills           = skills;
        this.selectedTemplate = selectedTemplate;
        this.dateCreated      = dateCreated;
    }

    @Override
    public String toString() {
        return fullName + " - " + jobTitle;
    }

    // ── Getters & Setters ──────────────────────────────────────────────────────

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getJobTitle() { return jobTitle; }
    public void setJobTitle(String jobTitle) { this.jobTitle = jobTitle; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getLinkedin() { return linkedin; }
    public void setLinkedin(String linkedin) { this.linkedin = linkedin; }

    public String getSchool() { return school; }
    public void setSchool(String school) { this.school = school; }

    public String getDegree() { return degree; }
    public void setDegree(String degree) { this.degree = degree; }

    public String getFieldOfStudy() { return fieldOfStudy; }
    public void setFieldOfStudy(String fieldOfStudy) { this.fieldOfStudy = fieldOfStudy; }

    public String getEduStartDate() { return eduStartDate; }
    public void setEduStartDate(String eduStartDate) { this.eduStartDate = eduStartDate; }

    public String getEduEndDate() { return eduEndDate; }
    public void setEduEndDate(String eduEndDate) { this.eduEndDate = eduEndDate; }

    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }

    public String getEduDescription() { return eduDescription; }
    public void setEduDescription(String eduDescription) { this.eduDescription = eduDescription; }

    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }

    public String getExpJobTitle() { return expJobTitle; }
    public void setExpJobTitle(String expJobTitle) { this.expJobTitle = expJobTitle; }

    public String getExpLocation() { return expLocation; }
    public void setExpLocation(String expLocation) { this.expLocation = expLocation; }

    public String getExpStartDate() { return expStartDate; }
    public void setExpStartDate(String expStartDate) { this.expStartDate = expStartDate; }

    public String getExpEndDate() { return expEndDate; }
    public void setExpEndDate(String expEndDate) { this.expEndDate = expEndDate; }

    public String getResponsibilities() { return responsibilities; }
    public void setResponsibilities(String responsibilities) { this.responsibilities = responsibilities; }

    public String getSkills() { return skills; }
    public void setSkills(String skills) { this.skills = skills; }

    public int getSelectedTemplate() { return selectedTemplate; }
    public void setSelectedTemplate(int selectedTemplate) { this.selectedTemplate = selectedTemplate; }

    public String getDateCreated() { return dateCreated; }
    public void setDateCreated(String dateCreated) { this.dateCreated = dateCreated; }
}
