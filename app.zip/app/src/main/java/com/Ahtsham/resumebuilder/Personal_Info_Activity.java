package com.Ahtsham.resumebuilder;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.Ahtsham.resumebuilder.model.ResumeData;

public class Personal_Info_Activity extends AppCompatActivity {

    private TextInputLayout   tilFullName, tilJobTitle, tilEmail, tilPhone;
    private TextInputEditText etFullName, etJobTitle, etEmail, etPhone,
                               etAddress, etLinkedin;
    private MaterialButton    btnNext;
    private TextView          btnBack;
    private ResumeData        resumeData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_info);

        resumeData = new ResumeData();

        // Fix W5: Use typed getSerializableExtra on API 33+, suppress deprecation below
        if (getIntent().hasExtra("resumeData")) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                resumeData = getIntent().getSerializableExtra("resumeData", ResumeData.class);
            } else {
                //noinspection deprecation
                resumeData = (ResumeData) getIntent().getSerializableExtra("resumeData");
            }
            if (resumeData == null) resumeData = new ResumeData();
        }

        // Find views
        tilFullName = findViewById(R.id.tilFullName);
        tilJobTitle = findViewById(R.id.tilJobTitle);
        tilEmail    = findViewById(R.id.tilEmail);
        tilPhone    = findViewById(R.id.tilPhone);
        etFullName  = findViewById(R.id.etFullName);
        etJobTitle  = findViewById(R.id.etJobTitle);
        etEmail     = findViewById(R.id.etEmail);
        etPhone     = findViewById(R.id.etPhone);
        etAddress   = findViewById(R.id.etAddress);
        etLinkedin  = findViewById(R.id.etLinkedin);
        btnNext     = findViewById(R.id.btnNext);
        btnBack     = findViewById(R.id.btnBack);

        // Pre-fill if editing
        if (resumeData.getFullName() != null) {
            etFullName.setText(resumeData.getFullName());
            etJobTitle.setText(resumeData.getJobTitle());
            etEmail.setText(resumeData.getEmail());
            etPhone.setText(resumeData.getPhone());
            etAddress.setText(resumeData.getAddress());
            etLinkedin.setText(resumeData.getLinkedin());
        }

        btnBack.setOnClickListener(v -> finish());
        btnNext.setOnClickListener(v -> validateAndProceed());
    }

    private void validateAndProceed() {
        String fullName = etFullName.getText().toString().trim();
        String jobTitle = etJobTitle.getText().toString().trim();
        String email    = etEmail.getText().toString().trim();
        String phone    = etPhone.getText().toString().trim();
        String address  = etAddress.getText().toString().trim();
        String linkedin = etLinkedin.getText().toString().trim();

        boolean isValid = true;

        if (fullName.isEmpty()) {
            tilFullName.setError("Full name is required");
            isValid = false;
        } else { tilFullName.setError(null); }

        if (jobTitle.isEmpty()) {
            tilJobTitle.setError("Job title is required");
            isValid = false;
        } else { tilJobTitle.setError(null); }

        if (email.isEmpty()) {
            tilEmail.setError("Email is required");
            isValid = false;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            // Fix S2: Use Android's built-in Patterns validator instead of
            // the weak email.contains("@") check that accepted invalid inputs like "@" or "a@"
            tilEmail.setError("Enter a valid email address");
            isValid = false;
        } else { tilEmail.setError(null); }

        if (phone.isEmpty()) {
            tilPhone.setError("Phone number is required");
            isValid = false;
        } else { tilPhone.setError(null); }

        if (isValid) {
            resumeData.setFullName(fullName);
            resumeData.setJobTitle(jobTitle);
            resumeData.setEmail(email);
            resumeData.setPhone(phone);
            resumeData.setAddress(address);
            resumeData.setLinkedin(linkedin);

            Intent intent = new Intent(this, EducationActivity.class);
            intent.putExtra("resumeData", resumeData);
            startActivity(intent);
        }
    }
}
