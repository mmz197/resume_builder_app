package com.Ahtsham.resumebuilder;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    private final Handler  handler  = new Handler(Looper.getMainLooper());
    private       Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // CRITICAL FIX: setContentView MUST come before getInsetsController().
        // On Samsung and many other devices, getInsetsController() returns null
        // before the window's decor view is attached (i.e. before setContentView),
        // causing an immediate NullPointerException crash on launch.
        setContentView(R.layout.activity_splash);

        // Fix W8: Full-screen — safe to call NOW because decor view is attached
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (getWindow().getInsetsController() != null) {
                getWindow().getInsetsController().hide(
                        android.view.WindowInsets.Type.statusBars());
            }
        } else {
            //noinspection deprecation
            getWindow().setFlags(
                    WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }

        // Fix C3: Store Runnable so it can be cancelled in onDestroy
        runnable = () -> {
            startActivity(new Intent(this, HomeActivity.class));
            finish();
        };
        handler.postDelayed(runnable, 2500);
    }

    @Override
    protected void onDestroy() {
        // Fix C3: Cancel navigation if user presses Back during splash
        handler.removeCallbacks(runnable);
        super.onDestroy();
    }
}
