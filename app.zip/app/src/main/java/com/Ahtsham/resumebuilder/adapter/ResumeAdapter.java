package com.Ahtsham.resumebuilder.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.Ahtsham.resumebuilder.R;
import com.Ahtsham.resumebuilder.model.ResumeData;

import java.util.List;

public class ResumeAdapter extends
        RecyclerView.Adapter<ResumeAdapter.ResumeViewHolder> {

    public interface OnResumeActionListener {
        void onPreview(ResumeData resume);
        void onDelete(ResumeData resume);
    }

    private List<ResumeData>             resumeList;
    private final OnResumeActionListener listener;

    public ResumeAdapter(List<ResumeData> resumeList,
                         OnResumeActionListener listener) {
        this.resumeList = resumeList;
        this.listener   = listener;
    }

    @NonNull
    @Override
    public ResumeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_resume, parent, false);
        return new ResumeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ResumeViewHolder holder, int position) {
        ResumeData resume = resumeList.get(position);
        holder.tvResumeName.setText(resume.getFullName());
        holder.tvResumeJobTitle.setText(resume.getJobTitle());
        holder.tvResumeDate.setText("Created: " +
                (resume.getDateCreated() != null ? resume.getDateCreated() : "--"));

        holder.btnPreview.setOnClickListener(v -> listener.onPreview(resume));

        holder.btnDelete.setOnClickListener(v ->
            // Fix: MaterialAlertDialogBuilder for proper Material3 dialog styling
            new MaterialAlertDialogBuilder(v.getContext())
                .setTitle("Delete Resume")
                .setMessage("Are you sure you want to delete this resume?")
                .setPositiveButton("Delete", (dialog, which) -> listener.onDelete(resume))
                .setNegativeButton("Cancel", null)
                .show()
        );
    }

    @Override
    public int getItemCount() { return resumeList.size(); }

    // DiffUtil for smooth list animations instead of notifyDataSetChanged()
    public void updateList(final List<ResumeData> newList) {
        DiffUtil.DiffResult result = DiffUtil.calculateDiff(new DiffUtil.Callback() {
            @Override public int getOldListSize() { return resumeList.size(); }
            @Override public int getNewListSize() { return newList.size(); }

            @Override
            public boolean areItemsTheSame(int oldPos, int newPos) {
                return resumeList.get(oldPos).getId() == newList.get(newPos).getId();
            }

            @Override
            public boolean areContentsTheSame(int oldPos, int newPos) {
                ResumeData o = resumeList.get(oldPos);
                ResumeData n = newList.get(newPos);
                return safeEquals(o.getFullName(),   n.getFullName())
                    && safeEquals(o.getJobTitle(),   n.getJobTitle())
                    && safeEquals(o.getDateCreated(), n.getDateCreated());
            }

            private boolean safeEquals(String a, String b) {
                if (a == null && b == null) return true;
                if (a == null || b == null) return false;
                return a.equals(b);
            }
        });
        this.resumeList = newList;
        result.dispatchUpdatesTo(this);
    }

    static class ResumeViewHolder extends RecyclerView.ViewHolder {
        TextView       tvResumeName, tvResumeJobTitle, tvResumeDate, btnDelete;
        MaterialButton btnPreview;

        ResumeViewHolder(@NonNull View itemView) {
            super(itemView);
            tvResumeName     = itemView.findViewById(R.id.tvResumeName);
            tvResumeJobTitle = itemView.findViewById(R.id.tvResumeJobTitle);
            tvResumeDate     = itemView.findViewById(R.id.tvResumeDate);
            btnPreview       = itemView.findViewById(R.id.btnPreview);
            btnDelete        = itemView.findViewById(R.id.btnDelete);
        }
    }
}
