package com.Ahtsham.resumebuilder;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.android.material.button.MaterialButton;
import com.Ahtsham.resumebuilder.database.DatabaseHelper;
import com.Ahtsham.resumebuilder.model.ResumeData;
import com.Ahtsham.resumebuilder.utils.PDFGenerator;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PreviewActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_EXPORT = 100;
    private static final int PERMISSION_REQUEST_SHARE  = 101;

    private LinearLayout llResumeHeader;
    private TextView     tvPreviewName, tvPreviewJobTitle,
                         tvPreviewContact, tvPreviewAddress,
                         tvPreviewSchool, tvPreviewDegree,
                         tvPreviewEduDates, tvPreviewGrade,
                         tvPreviewCompany, tvPreviewExpTitle,
                         tvPreviewExpDates, tvPreviewResponsibilities,
                         tvPreviewSkills, btnBack, btnShare;
    private MaterialButton btnExportPDF, btnEditResume;

    private ResumeData     resumeData;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);

        db = new DatabaseHelper(this);

        // W5: API 33+ typed getSerializableExtra
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            resumeData = getIntent().getSerializableExtra("resumeData", ResumeData.class);
        } else {
            //noinspection deprecation
            resumeData = (ResumeData) getIntent().getSerializableExtra("resumeData");
        }

        if (resumeData == null) {
            Toast.makeText(this, "Error loading resume data", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        bindViews();
        saveOrUpdateResume();
        populateResumeView();

        btnBack.setOnClickListener(v -> finish());
        btnEditResume.setOnClickListener(v -> {
            Intent intent = new Intent(this, Personal_Info_Activity.class);
            intent.putExtra("resumeData", resumeData);
            startActivity(intent);
        });
        btnExportPDF.setOnClickListener(v -> exportResume());
        btnShare.setOnClickListener(v -> shareResume());
    }

    private void bindViews() {
        llResumeHeader            = findViewById(R.id.llResumeHeader);
        tvPreviewName             = findViewById(R.id.tvPreviewName);
        tvPreviewJobTitle         = findViewById(R.id.tvPreviewJobTitle);
        tvPreviewContact          = findViewById(R.id.tvPreviewContact);
        tvPreviewAddress          = findViewById(R.id.tvPreviewAddress);
        tvPreviewSchool           = findViewById(R.id.tvPreviewSchool);
        tvPreviewDegree           = findViewById(R.id.tvPreviewDegree);
        tvPreviewEduDates         = findViewById(R.id.tvPreviewEduDates);
        tvPreviewGrade            = findViewById(R.id.tvPreviewGrade);
        tvPreviewCompany          = findViewById(R.id.tvPreviewCompany);
        tvPreviewExpTitle         = findViewById(R.id.tvPreviewExpTitle);
        tvPreviewExpDates         = findViewById(R.id.tvPreviewExpDates);
        tvPreviewResponsibilities = findViewById(R.id.tvPreviewResponsibilities);
        tvPreviewSkills           = findViewById(R.id.tvPreviewSkills);
        btnExportPDF              = findViewById(R.id.btnExportPDF);
        btnEditResume             = findViewById(R.id.btnEditResume);
        btnBack                   = findViewById(R.id.btnBack);
        btnShare                  = findViewById(R.id.btnShare);
    }

    @Override
    protected void onDestroy() {
        if (db != null) db.close();
        super.onDestroy();
    }

    // Insert new resume or update existing one based on ID
    private void saveOrUpdateResume() {
        if (resumeData.getId() == 0) {
            String date = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                    .format(new Date());
            resumeData.setDateCreated(date);
            long newId = db.insertResume(resumeData);
            if (newId != -1) {
                resumeData.setId((int) newId);
            } else {
                Toast.makeText(this, "Warning: Could not save resume to database",
                        Toast.LENGTH_LONG).show();
            }
        } else {
            db.updateResume(resumeData);
        }
    }

    private void populateResumeView() {
        // Fix: Use ContextCompat.getColor() instead of Color.parseColor() hardcoded hex
        int templateColor = resumeData.getSelectedTemplate() == 1
                ? ContextCompat.getColor(this, R.color.colorPrimary)
                : ContextCompat.getColor(this, R.color.colorSuccess);
        llResumeHeader.setBackgroundColor(templateColor);

        // Personal — name and job title are required so always set
        tvPreviewName.setText(resumeData.getFullName());
        tvPreviewJobTitle.setText(resumeData.getJobTitle());

        // Contact line — build and hide if truly empty
        StringBuilder contact = new StringBuilder();
        if (!isEmpty(resumeData.getEmail()))
            contact.append(resumeData.getEmail());
        if (!isEmpty(resumeData.getPhone())) {
            if (contact.length() > 0) contact.append("  |  ");
            contact.append(resumeData.getPhone());
        }
        if (!isEmpty(resumeData.getLinkedin())) {
            if (contact.length() > 0) contact.append("\n");
            contact.append(resumeData.getLinkedin());
        }
        // Fix: use setTextOrHide so XML placeholder doesn't bleed through
        setTextOrHide(tvPreviewContact, contact.toString());
        setTextOrHide(tvPreviewAddress, resumeData.getAddress());

        // Education — use setTextOrHide so XML placeholders don't bleed through
        setTextOrHide(tvPreviewSchool, resumeData.getSchool());

        String degree = "";
        if (!isEmpty(resumeData.getDegree())) degree += resumeData.getDegree();
        if (!isEmpty(resumeData.getFieldOfStudy()))
            degree += (degree.isEmpty() ? "" : " — ") + resumeData.getFieldOfStudy();
        setTextOrHide(tvPreviewDegree, degree);

        String eduDates = "";
        if (!isEmpty(resumeData.getEduStartDate())) eduDates += resumeData.getEduStartDate();
        if (!isEmpty(resumeData.getEduEndDate()))
            eduDates += (eduDates.isEmpty() ? "" : " — ") + resumeData.getEduEndDate();
        setTextOrHide(tvPreviewEduDates, eduDates);

        if (!isEmpty(resumeData.getGrade())) {
            tvPreviewGrade.setText("CGPA: " + resumeData.getGrade());
            tvPreviewGrade.setVisibility(View.VISIBLE);
        } else {
            tvPreviewGrade.setVisibility(View.GONE);
        }

        // Experience — all optional, hide if empty
        setTextOrHide(tvPreviewCompany,         resumeData.getCompanyName());
        setTextOrHide(tvPreviewExpTitle,         resumeData.getExpJobTitle());

        String expDates = "";
        if (!isEmpty(resumeData.getExpStartDate())) expDates += resumeData.getExpStartDate();
        if (!isEmpty(resumeData.getExpEndDate()))
            expDates += (expDates.isEmpty() ? "" : " — ") + resumeData.getExpEndDate();
        setTextOrHide(tvPreviewExpDates, expDates);
        setTextOrHide(tvPreviewResponsibilities, resumeData.getResponsibilities());

        // Skills
        setTextOrHide(tvPreviewSkills, resumeData.getSkills());
    }

    // ── PDF Export ──────────────────────────────────────────────────────────────

    private void exportResume() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
                ContextCompat.checkSelfPermission(this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    PERMISSION_REQUEST_EXPORT);
            return;
        }
        generateAndSavePDF();
    }

    private void generateAndSavePDF() {
        Toast.makeText(this, "Generating PDF...", Toast.LENGTH_SHORT).show();
        File pdfFile = PDFGenerator.generatePDF(this, resumeData);
        if (pdfFile != null) {
            Toast.makeText(this, "PDF saved to Downloads: " + pdfFile.getName(),
                    Toast.LENGTH_LONG).show();
            openPDF(pdfFile);
        } else {
            Toast.makeText(this, "Export failed. Please try again.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void openPDF(File file) {
        try {
            Uri uri = FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/pdf");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Open PDF with"));
        } catch (Exception e) {
            Toast.makeText(this, "PDF saved! Check your Downloads folder.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void shareResume() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
                ContextCompat.checkSelfPermission(this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    PERMISSION_REQUEST_SHARE);
            return;
        }
        doShareResume();
    }

    private void doShareResume() {
        File pdfFile = PDFGenerator.generatePDF(this, resumeData);
        if (pdfFile != null) {
            try {
                Uri uri = FileProvider.getUriForFile(
                        this, getPackageName() + ".fileprovider", pdfFile);
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("application/pdf");
                shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(shareIntent, "Share Resume via"));
            } catch (Exception e) {
                Toast.makeText(this, "PDF saved to Downloads!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Could not generate PDF", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (requestCode == PERMISSION_REQUEST_EXPORT)     generateAndSavePDF();
            else if (requestCode == PERMISSION_REQUEST_SHARE) doShareResume();
        } else {
            Toast.makeText(this, "Permission needed to save PDF", Toast.LENGTH_SHORT).show();
        }
    }

    // ── Helpers ─────────────────────────────────────────────────────────────────

    private void setTextOrHide(TextView tv, String value) {
        if (!isEmpty(value)) {
            tv.setText(value);
            tv.setVisibility(View.VISIBLE);
        } else {
            tv.setVisibility(View.GONE);
        }
    }

    private boolean isEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }
}
