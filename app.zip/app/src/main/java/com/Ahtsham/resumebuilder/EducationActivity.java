package com.Ahtsham.resumebuilder;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.Ahtsham.resumebuilder.model.ResumeData;

public class EducationActivity extends AppCompatActivity {

    private TextInputLayout   tilSchool, tilDegree, tilFieldOfStudy,
                               tilEduStartDate, tilEduEndDate;
    private TextInputEditText etSchool, etDegree, etFieldOfStudy,
                               etEduStartDate, etEduEndDate,
                               etGrade, etEduDesc;
    private MaterialButton    btnNextExperience;
    private TextView          btnBack;
    private ResumeData        resumeData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_education);

        // Fix W5: Use typed getSerializableExtra on API 33+, suppress deprecation below
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            resumeData = getIntent().getSerializableExtra("resumeData", ResumeData.class);
        } else {
            //noinspection deprecation
            resumeData = (ResumeData) getIntent().getSerializableExtra("resumeData");
        }
        if (resumeData == null) resumeData = new ResumeData();

        // Find views
        tilSchool        = findViewById(R.id.tilSchool);
        tilDegree        = findViewById(R.id.tilDegree);
        tilFieldOfStudy  = findViewById(R.id.tilFieldOfStudy);
        tilEduStartDate  = findViewById(R.id.tilEduStartDate);
        tilEduEndDate    = findViewById(R.id.tilEduEndDate);
        etSchool         = findViewById(R.id.etSchool);
        etDegree         = findViewById(R.id.etDegree);
        etFieldOfStudy   = findViewById(R.id.etFieldOfStudy);
        etEduStartDate   = findViewById(R.id.etEduStartDate);
        etEduEndDate     = findViewById(R.id.etEduEndDate);
        etGrade          = findViewById(R.id.etGrade);
        etEduDesc        = findViewById(R.id.etEduDesc);
        btnNextExperience= findViewById(R.id.btnNextExperience);
        btnBack          = findViewById(R.id.btnBack);

        // Pre-fill if editing
        if (resumeData.getSchool() != null) {
            etSchool.setText(resumeData.getSchool());
            etDegree.setText(resumeData.getDegree());
            etFieldOfStudy.setText(resumeData.getFieldOfStudy());
            etEduStartDate.setText(resumeData.getEduStartDate());
            etEduEndDate.setText(resumeData.getEduEndDate());
            etGrade.setText(resumeData.getGrade());
            etEduDesc.setText(resumeData.getEduDescription());
        }

        btnBack.setOnClickListener(v -> finish());
        btnNextExperience.setOnClickListener(v -> validateAndProceed());
    }

    private void validateAndProceed() {
        String school       = etSchool.getText().toString().trim();
        String degree       = etDegree.getText().toString().trim();
        String fieldOfStudy = etFieldOfStudy.getText().toString().trim();
        String startDate    = etEduStartDate.getText().toString().trim();
        String endDate      = etEduEndDate.getText().toString().trim();
        String grade        = etGrade.getText().toString().trim();
        String desc         = etEduDesc.getText().toString().trim();

        boolean isValid = true;

        if (school.isEmpty()) {
            tilSchool.setError("School name is required");
            isValid = false;
        } else { tilSchool.setError(null); }

        if (degree.isEmpty()) {
            tilDegree.setError("Degree is required");
            isValid = false;
        } else { tilDegree.setError(null); }

        if (fieldOfStudy.isEmpty()) {
            tilFieldOfStudy.setError("Field of study is required");
            isValid = false;
        } else { tilFieldOfStudy.setError(null); }

        if (startDate.isEmpty()) {
            tilEduStartDate.setError("Start year required");
            isValid = false;
        } else { tilEduStartDate.setError(null); }

        if (endDate.isEmpty()) {
            tilEduEndDate.setError("End year required");
            isValid = false;
        } else { tilEduEndDate.setError(null); }

        if (isValid) {
            resumeData.setSchool(school);
            resumeData.setDegree(degree);
            resumeData.setFieldOfStudy(fieldOfStudy);
            resumeData.setEduStartDate(startDate);
            resumeData.setEduEndDate(endDate);
            resumeData.setGrade(grade);
            resumeData.setEduDescription(desc);

            Intent intent = new Intent(this, ExperienceActivity.class);
            intent.putExtra("resumeData", resumeData);
            startActivity(intent);
        }
    }
}
