package com.Ahtsham.resumebuilder;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.Ahtsham.resumebuilder.model.ResumeData;

public class ExperienceActivity extends AppCompatActivity {

    private TextInputEditText etCompanyName, etExpJobTitle,
                               etExpLocation, etExpStartDate,
                               etExpEndDate, etResponsibilities;
    private MaterialButton    btnNextSkills, btnSkip;
    private TextView          btnBack;
    private ResumeData        resumeData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_experience);

        // Fix W5: Use typed getSerializableExtra on API 33+, suppress deprecation below
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            resumeData = getIntent().getSerializableExtra("resumeData", ResumeData.class);
        } else {
            //noinspection deprecation
            resumeData = (ResumeData) getIntent().getSerializableExtra("resumeData");
        }
        if (resumeData == null) resumeData = new ResumeData();

        // Find views
        etCompanyName      = findViewById(R.id.etCompanyName);
        etExpJobTitle      = findViewById(R.id.etExpJobTitle);
        etExpLocation      = findViewById(R.id.etExpLocation);
        etExpStartDate     = findViewById(R.id.etExpStartDate);
        etExpEndDate       = findViewById(R.id.etExpEndDate);
        etResponsibilities = findViewById(R.id.etResponsibilities);
        btnNextSkills      = findViewById(R.id.btnNextSkills);
        btnSkip            = findViewById(R.id.btnSkip);
        btnBack            = findViewById(R.id.btnBack);

        // Pre-fill if editing
        if (resumeData.getCompanyName() != null) {
            etCompanyName.setText(resumeData.getCompanyName());
            etExpJobTitle.setText(resumeData.getExpJobTitle());
            etExpLocation.setText(resumeData.getExpLocation());
            etExpStartDate.setText(resumeData.getExpStartDate());
            etExpEndDate.setText(resumeData.getExpEndDate());
            etResponsibilities.setText(resumeData.getResponsibilities());
        }

        btnBack.setOnClickListener(v -> finish());

        // Skip button — go to Skills without saving experience
        btnSkip.setOnClickListener(v -> {
            Intent intent = new Intent(this, SkillsActivity.class);
            intent.putExtra("resumeData", resumeData);
            startActivity(intent);
        });

        btnNextSkills.setOnClickListener(v -> saveAndProceed());
    }

    private void saveAndProceed() {
        // Experience is optional — no strict validation
        resumeData.setCompanyName(etCompanyName.getText().toString().trim());
        resumeData.setExpJobTitle(etExpJobTitle.getText().toString().trim());
        resumeData.setExpLocation(etExpLocation.getText().toString().trim());
        resumeData.setExpStartDate(etExpStartDate.getText().toString().trim());
        resumeData.setExpEndDate(etExpEndDate.getText().toString().trim());
        resumeData.setResponsibilities(etResponsibilities.getText().toString().trim());

        Intent intent = new Intent(this, SkillsActivity.class);
        intent.putExtra("resumeData", resumeData);
        startActivity(intent);
    }
}
